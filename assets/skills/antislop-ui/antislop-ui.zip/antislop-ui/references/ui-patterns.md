# Generic UI patterns

Each entry: the tell, why it reads as generic, and a better move.

## Colour
- **Purple-to-blue gradient hero** (#6366f1 → #8b5cf6, "indigo/violet"): the single most common AI default. → Pick a palette from the product's world; use a flat field or a subtle tonal ground.
- **Neon accent on near-black** (acid green, electric blue): reads as "crypto template". → Desaturate, or use the accent only for one element.
- **Warm cream + terracotta + serif**: the "tasteful AI" default. → Fine only if the subject calls for it; otherwise choose deliberately.
- **Pure mid-grey neutrals** (#6b7280 everywhere): looks unconsidered. → Tint neutrals slightly toward the accent.
- **Rainbow of tints** for every card. → One accent, semantic colours for status only.

## Type
- **Inter / Space Grotesk / Plus Jakarta everywhere**, one weight, one size step. → Pair a characterful display face with a readable body face; set a real scale.
- **Gradient text headlines.** → Solid ink; let size and weight carry emphasis.
- **All-caps tracking-widest labels everywhere.** → Use eyebrows sparingly and only to label true categories.

## Layout
- **Everything centered**, every section the same width and height. → Mix alignments; let content set height.
- **Three equal feature cards with icons** repeated down the page ("card soup"). → Vary the form: a list, a table, a screenshot with callouts.
- **Bento grid with filler tiles.** → Only if each tile has real content.
- **Giant 100vh hero** that pushes all content below the fold. → Size the hero to its content.
- **Numbered 01/02/03 markers** on things that aren't a sequence. → Remove numbers unless order matters.

## Components and effects
- **rounded-2xl + shadow-lg on every block.** → Card styling by role only.
- **Glassmorphism panels and blurred blobs** behind everything. → One atmospheric effect at most.
- **Emoji as section icons** (🚀 ✨ 💡). → A consistent icon set or none.
- **Accent bar on the left of rounded cards.** → Remove; use hierarchy instead.
- **Floating gradient "glow" buttons.** → A solid, well-sized primary button.

## Content
- **Fake social proof**: invented logos, "Trusted by 10,000+ teams", generic avatar testimonials. → Real proof or none.
- **Placeholder metrics**: "99.9% uptime", "10x faster" with no source. → Real numbers with context.
- **Buzzword headlines**: "Supercharge your workflow", "Unlock your potential", "The future of X". → Say what the product does for whom.
- **Lorem-like filler** and "Feature one / Feature two". → Real copy.
- **"Get started" as every CTA.** → A verb that names the outcome ("Book a demo", "Start a free audit").
