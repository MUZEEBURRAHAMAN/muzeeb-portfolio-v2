# Slop patterns

Mark every instance. Each category lists examples and the fix.

## 1. Throat-clearing openers
Examples: "Here's the thing:", "Let's dive in", "Let's be honest", "It's worth noting that", "In today's fast-paced world", "When it comes to", "At the end of the day", "The truth is", "Let me be clear", "I'm going to be honest".
Fix: delete; start with the claim.

## 2. Fake profundity
Examples: "Let that sink in.", "Read that again.", "This changes everything.", "And that's okay.", "Full stop.", "Period.", "That's the real unlock.", "The uncomfortable truth is…".
Fix: delete, or replace with the evidence that would make the reader feel it.

## 3. Binary contrasts
Examples: "It's not X, it's Y.", "Not because A. Because B.", "This isn't about X. It's about Y.", "X isn't the problem. Y is."
Fix: state Y directly.

## 4. Dramatic fragments and one-liners
Examples: "Clarity. That's it. That's the foundation.", paragraphs ending in a three-word mic-drop.
Fix: fold into a full sentence; let some paragraphs end on a plain fact.

## 5. Reflexive triplets
Examples: "clarity, speed, and trust", "faster, smarter, better", three adjectives in a row.
Fix: keep the strongest one or two; use three only when there really are three.

## 6. Rhetorical Q&A
Examples: "So what's the answer? Focus.", "Why does this matter? Because…".
Fix: give the answer as a statement.

## 7. Vague business abstractions
Examples: "drive impact", "unlock value", "leverage synergies", "navigate the landscape", "move the needle", "empower teams", "robust", "seamless", "cutting-edge", "game-changer", "best-in-class", "delve", "tapestry", "realm", "elevate".
Fix: name the concrete action and result.

## 8. Hedges and intensifiers
Examples: "very", "really", "truly", "incredibly", "arguably", "somewhat", "quite", "it's important to note", "it's crucial to".
Fix: delete, or replace with a precise word or number.

## 9. Passive and false agency
Examples: "Mistakes were made", "The decision was taken", "The data tells a story", "The market rewards…".
Fix: name the person or team doing the thing.

## 10. Punctuation tells
Examples: em dashes (—) used for asides, excessive colons before reveals, sentences starting with "So," or "Look,".
Fix: full stops, commas, parentheses; start with the subject.

## 11. Narrator distance
Examples: "Many people believe", "Some would say", "Nobody talks about this".
Fix: put the reader or a specific person in the sentence ("You'll notice", "Our design lead argued").

## 12. Meta-commentary
Examples: "In this post, I'll explain", "As mentioned above", "The rest of this article", "In conclusion".
Fix: delete; let the structure carry the reader.
